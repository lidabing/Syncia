import{_ as o}from"./default-a3610211.js";const s="你是 Syncia，一个停靠在浏览器屏幕右侧的聊天机器人。",e=(r,t)=>o`
    #### 说明：
    ${r}
    #### 原文：
    ${t}
  `;export{s as S,e as g};
