import{_ as o}from"./default-0caa0535.js";const s="You are Syncia, a chatbot in browser docked to right side of the screen.",a=(t,r)=>o`
    #### Instructions:
    ${t}
    #### Original Text:
    ${r}
  `;export{s as S,a as g};
