import{S as L,A as C}from"./pageVision-cf20fed4.js";const v=` ____                   _
/ ___| _   _ _ __   ___(_) __ _
\\___ \\| | | | '_ \\ / __| |/ _\` |
 ___) | |_| | | | | (__| | (_| |
|____/ \\__, |_| |_|\\___|_|\\__,_|
       |___/`,I=e=>`
${" ".repeat(14-e.length/2)}[${e}]`,O=e=>{console.log(v,I(`${e} Script Loaded`))},D=()=>{console.log(v,I("Background Loaded"))};function P(){return Math.random().toString(36).substring(2,10)}function S(e,t,o){const n=`${e} ${t} ${o||""}`.toLowerCase();return L.some(a=>n.includes(a.toLowerCase()))}async function U(e,t,o){return new Promise((n,a)=>{const s=new Image;s.onload=()=>{const g=document.createElement("canvas");let{width:r,height:i}=s;r>t&&(i=Math.round(i*t/r),r=t),g.width=r,g.height=i;const u=g.getContext("2d");if(!u){a(new Error("Failed to get canvas context"));return}u.drawImage(s,0,0,r,i);const m=g.toDataURL("image/jpeg",o);n(m)},s.onerror=()=>a(new Error("Failed to load image")),s.src=e})}function A(){return`你是一个智能浏览器助手，具备视觉分析能力。你的任务是：
1. 分析用户当前浏览的页面截图
2. 识别页面类型和内容
3. 推测用户可能的需求和意图
4. 提供精准、实用的操作建议

页面类别 (pageCategory):
- ecommerce: 电商/购物页面（商品详情、价格、评论等）
- coding: 代码/技术页面（GitHub、StackOverflow、IDE、终端等）
- article: 新闻/博客/文章（长文本内容）
- documentation: 技术文档（API文档、使用指南等）
- social: 社交媒体（微博、Twitter、论坛等）
- video: 视频平台（YouTube、B站等）
- dashboard: 数据面板/后台（图表、统计数据等）
- form: 表单/预订页面（需要填写信息）
- search: 搜索结果页
- general: 其他通用页面

用户意图 (userIntent):
- browsing: 随意浏览
- learning: 学习/研究
- debugging: 调试/解决问题
- shopping: 购物决策
- comparing: 比较分析
- reading: 深度阅读
- filling_form: 填写表单
- watching: 观看视频
- unknown: 无法确定

请严格按照 JSON 格式返回分析结果，不要包含任何其他文本。`}function V(e,t,o,n){return`请分析这个网页${o?"截图":""}并推测用户意图。

页面信息：
- 标题: ${e}
- URL: ${t}
${n?`- 额外上下文: ${n}`:""}

请返回以下 JSON 格式：
{
  "pageCategory": "string (从给定类别中选择)",
  "userIntent": "string (从给定意图中选择)",
  "reasoning": "string (用一句话解释你的推理过程)",
  "confidence": number (0-1 的置信度),
  "pageSummary": "string (页面一句话摘要，不超过50字)",
  "keyElements": ["string (识别到的关键元素，最多5个)"],
  "actions": [
    {
      "label": "string (按钮文字，4-8字)",
      "query": "string (发送给 AI 的详细提问)",
      "priority": number (1-5，越小越重要),
      "category": "primary | secondary | utility"
    }
  ],
  "metadata": {
    "detectedLanguage": "zh | en | other",
    "hasCode": boolean,
    "hasPricing": boolean,
    "hasForm": boolean,
    "hasVideo": boolean
  }
}

要求：
1. actions 必须提供 3-5 个实用操作建议
2. 每个 action 的 query 应该是完整的、可直接发送给 AI 的问题
3. 优先考虑用户最可能需要的操作
4. 基于具体页面内容定制建议，而非通用建议`}function x(e,t="general"){try{const o=e.match(/\{[\s\S]*\}/);if(!o)return console.warn("[PageVision] No JSON found in response"),{pageCategory:t};const n=JSON.parse(o[0]);return{pageCategory:n.pageCategory||t,userIntent:n.userIntent||"unknown",reasoning:n.reasoning||"",confidence:Math.min(1,Math.max(0,n.confidence||.5)),pageSummary:n.pageSummary||"",keyElements:Array.isArray(n.keyElements)?n.keyElements.slice(0,5):[],actions:(n.actions||[]).map(a=>({id:P(),label:a.label||"操作",query:a.query||a.label,priority:a.priority||3,category:a.category||"secondary"})),metadata:n.metadata||{}}}catch(o){return console.error("[PageVision] Failed to parse response:",o),{pageCategory:t}}}function k(e){return(C[e]||C.general).map((o,n)=>({id:P(),label:o.label||"操作",query:o.query||o.label||"",priority:o.priority||n+1,category:o.category||"secondary"}))}function M(e){const t=["gpt-4o","gpt-4o-mini","gpt-4-vision","gpt-4-turbo","claude-3","claude-3.5","claude-3-opus","claude-3-sonnet","claude-3-haiku","gemini-1.5","gemini-pro-vision","gemini-2","qwen-vl","qwen2-vl","glm-4v","deepseek-vl"],o=e.toLowerCase();return t.some(n=>o.includes(n.toLowerCase()))}async function F(e,t,o,n,a,s,g){var m,b;const r=M(s),i=e&&r;console.log("[PageVision] Starting analysis...",{hasScreenshot:!!e,supportsVision:r,useScreenshot:i,model:s,pageTitle:t,url:o}),e&&!r&&(console.warn(`[PageVision] Model "${s}" does not support vision. Falling back to text-only analysis.`),console.warn("[PageVision] Consider using a vision-capable model like gpt-4o, claude-3.5-sonnet, etc."));const u=Date.now();try{const p=A(),l=V(t,o,!!i,g);let y;if(i){const w=e.startsWith("data:")?e:`data:image/jpeg;base64,${e}`;y=[{type:"text",text:l},{type:"image_url",image_url:{url:w,detail:"low"}}]}else y=l;const h=new AbortController,$=setTimeout(()=>h.abort(),6e4),d=await fetch(`${a||"https://api.openai.com"}/v1/chat/completions`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${n}`},body:JSON.stringify({model:s||"gpt-4o",messages:[{role:"system",content:p},{role:"user",content:y}],max_tokens:1e3,temperature:.3}),signal:h.signal});if(clearTimeout($),!d.ok){const w=await d.text();throw new Error(`API error: ${d.status} - ${w}`)}const f=((b=(m=(await d.json()).choices[0])==null?void 0:m.message)==null?void 0:b.content)||"";console.log("[PageVision] AI response:",f);const c=x(f);let _=c.actions||[];_.length===0&&(_=k(c.pageCategory||"general"));const E={pageCategory:c.pageCategory||"general",userIntent:c.userIntent||"unknown",reasoning:c.reasoning||"页面分析完成",confidence:c.confidence||.7,pageSummary:c.pageSummary||`正在查看: ${t}`,keyElements:c.keyElements||[],actions:_,metadata:{...c.metadata,sensitiveContent:S(t,o),visionModelUsed:r,modelName:s},timestamp:Date.now(),screenshotUsed:!!i,screenshotUrl:e||void 0};return console.log("[PageVision] Analysis complete in",Date.now()-u,"ms"),E}catch(p){console.error("[PageVision] Analysis failed:",p);const l=T(o);return{pageCategory:l,userIntent:"browsing",reasoning:"分析出错，使用默认建议",confidence:.3,pageSummary:t,keyElements:[],actions:k(l),metadata:{sensitiveContent:S(t,o)},timestamp:Date.now(),screenshotUsed:!!e}}}function T(e){const t=new URL(e).hostname.toLowerCase(),o=new URL(e).pathname.toLowerCase();return/amazon|taobao|jd\.com|tmall|ebay|shopee|aliexpress/.test(t)?"ecommerce":/github|gitlab|stackoverflow|codepen|codesandbox|replit/.test(t)?"coding":/youtube|bilibili|vimeo|youku|iqiyi/.test(t)?"video":/twitter|weibo|facebook|instagram|reddit|zhihu|douban/.test(t)?"social":/docs\.|documentation|wiki|readme|api\./.test(t)||/\/docs\/|\/api\/|\/wiki\//.test(o)?"documentation":/google\.com\/search|bing\.com\/search|baidu\.com\/s/.test(e)?"search":/medium|substack|ghost|wordpress|news|blog/.test(t)?"article":"general"}export{U as a,F as b,O as c,S as d,D as e};
