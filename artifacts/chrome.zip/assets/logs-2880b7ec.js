const o=` ____                   _
/ ___| _   _ _ __   ___(_) __ _
\\___ \\| | | | '_ \\ / __| |/ _\` |
 ___) | |_| | | | | (__| | (_| |
|____/ \\__, |_| |_|\\___|_|\\__,_|
       |___/`,n=_=>`
${" ".repeat(14-_.length/2)}[${_}]`,t=_=>{console.log(o,n(`${_} Script Loaded`))},c=()=>{console.log(o,n("Background Loaded"))};export{c as b,t as c};
